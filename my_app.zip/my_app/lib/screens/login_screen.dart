// login_screen.dart removed by request — login page deleted from the app.
// Remove references to `LoginScreen` or the '/login' route in your codebase.
