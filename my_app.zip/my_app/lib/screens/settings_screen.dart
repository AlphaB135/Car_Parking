// settings_screen.dart removed by request — settings page deleted from the app.
// Remove references to `SettingsScreen` or the '/settings' route in your codebase.
